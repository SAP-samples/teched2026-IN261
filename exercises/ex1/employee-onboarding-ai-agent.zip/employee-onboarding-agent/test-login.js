// test-login.js
// Quick standalone test — runs the IAS login flow and prints the logged-in user.
// Run with: node test-login.js

import { loginWithIAS } from "./tools/ias-login.js";

console.log("[Test] Testing IAS login flow...\n");

try {
  const token = await loginWithIAS();

  // JWT is three base64 parts separated by dots — the middle part is the claims
  const claims = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());

  console.log("[Test] Logged in as:");
  console.log(`  Name:  ${claims.given_name} ${claims.family_name}`);
  console.log(`  Email: ${claims.email}`);
  console.log(`  User:  ${claims.sub}`);
  console.log("\n[Test] Login successful — identity ready for Principal Propagation.\n");
} catch (err) {
  console.error("[Test] Login failed:", err.message);
}
