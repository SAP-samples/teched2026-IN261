// ias-login.js
// Handles login via SAP Identity Authentication Service (IAS) using OIDC + PKCE.
// Opens the participant's browser, waits for the callback on localhost, and returns an access token.
// No client secret needed — PKCE makes this safe for a public client running on a laptop.

import http from "http";
import crypto from "crypto";
import { exec } from "child_process";
import fetch from "node-fetch";
import "dotenv/config";

const IAS_TENANT  = process.env.IAS_TENANT;
const CLIENT_ID   = process.env.OIDC_CLIENT_ID;
const REDIRECT    = process.env.OIDC_REDIRECT_URI;
const PORT        = 3000;

// Fail early with a clear message if any required env vars are missing
const missing = ["IAS_TENANT", "OIDC_CLIENT_ID", "OIDC_REDIRECT_URI"].filter((k) => !process.env[k]);
if (missing.length > 0) {
  throw new Error(`Missing required environment variables: ${missing.join(", ")}\nCheck your .env file.`);
}

// ── PKCE helpers ──────────────────────────────────────────────────────────────

function generateVerifier() {
  // Random 64-byte string, URL-safe base64 encoded — this is the secret we keep locally
  return crypto.randomBytes(64).toString("base64url");
}

function generateChallenge(verifier) {
  // SHA-256 hash of the verifier, sent to IAS so it can verify us later
  return crypto.createHash("sha256").update(verifier).digest("base64url");
}

// ── Browser opener (works on Mac, Linux, Windows) ────────────────────────────

function openBrowser(url) {
  const cmd =
    process.platform === "darwin" ? `open "${url}"` :
    process.platform === "win32"  ? `start "" "${url}"` :
                                    `xdg-open "${url}"`;
  exec(cmd);
}

// ── Main login function ───────────────────────────────────────────────────────

export async function loginWithIAS() {
  const verifier  = generateVerifier();
  const challenge = generateChallenge(verifier);

  // Build the IAS authorization URL
  const authUrl =
    `https://${IAS_TENANT}/oauth2/authorize` +
    `?client_id=${CLIENT_ID}` +
    `&redirect_uri=${encodeURIComponent(REDIRECT)}` +
    `&response_type=code` +
    `&scope=openid%20profile%20email` +
    `&code_challenge=${challenge}` +
    `&code_challenge_method=S256`;

  console.log("\n[Login] Opening your browser for SAP IAS login...");
  console.log("[Login] Authorization URL:");
  console.log(`\n  ${authUrl}\n`);

  openBrowser(authUrl);

  // Wait for IAS to redirect back to localhost:3000/callback with the auth code
  const code = await waitForCallback();

  console.log(`[Login] Auth code received: ${code}\n`);

  // Exchange the auth code + PKCE verifier for an access token
  const token = await exchangeCodeForToken(code, verifier);

  console.log("[Login] Access token received:");
  console.log(`\n  ${token}\n`);

  // Decode the JWT to show who just logged in (no library needed — JWT is just base64)
  const claims = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());
  console.log(`[Login] Logged in as: ${claims.given_name} ${claims.family_name} (${claims.email})`);
  console.log("[Login] Identity will be propagated to S/4HANA via Principal Propagation.\n");

  return token;
}

// ── Wait for IAS to redirect back to localhost ────────────────────────────────

function waitForCallback() {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      // IAS calls: GET /callback?code=xxxx
      const url    = new URL(req.url, `http://localhost:${PORT}`);
      const code   = url.searchParams.get("code");
      const error  = url.searchParams.get("error");

      if (error) {
        res.end("Login failed. You can close this tab.");
        server.close();
        reject(new Error(`IAS login error: ${error}`));
        return;
      }

      if (code) {
        res.end("Login successful! You can close this tab and return to the Employee Onboarding AI Agent Terminal.");
        server.close();
        resolve(code);
      }
    });

    server.listen(PORT, () => {
      // Server is ready — browser will land here after IAS login
    });

    server.on("error", (err) => {
      if (err.code === "EADDRINUSE") {
        const isWindows = process.platform === "win32";
        const instructions = isWindows
          ? `  Find what is using it:  netstat -ano | findstr :${PORT}\n` +
            `  Stop it:                taskkill /PID <pid from above> /F`
          : `  Find what is using it:  lsof -i :${PORT}\n` +
            `  Stop it:                kill $(lsof -t -i :${PORT})`;
        reject(new Error(
          `Port ${PORT} is already in use.\n` +
          instructions + `\n` +
          `  Then re-run the agent.`
        ));
      } else {
        reject(err);
      }
    });

    // Give the participant 5 minutes to log in before timing out
    setTimeout(() => {
      server.close();
      reject(new Error("Login timed out after 5 minutes."));
    }, 5 * 60 * 1000);
  });
}

// ── Exchange auth code for access token ──────────────────────────────────────

async function exchangeCodeForToken(code, verifier) {
  const res = await fetch(`https://${IAS_TENANT}/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type:    "authorization_code",
      client_id:     CLIENT_ID,
      redirect_uri:  REDIRECT,
      code:          code,
      code_verifier: verifier,   // IAS verifies this matches the challenge we sent earlier
    }),
  });

  if (!res.ok) {
    throw new Error(`Token exchange failed: ${res.status} ${await res.text()}`);
  }

  const data = await res.json();
  return data.access_token;
}
