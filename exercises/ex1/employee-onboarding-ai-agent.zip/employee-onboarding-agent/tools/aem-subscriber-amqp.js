import { Connection } from "rhea-promise";
import "dotenv/config";

export async function connectAEM(onMessage) {
  const connection = new Connection({
    hostname: process.env.AEM_HOST,
    host: process.env.AEM_HOST,
    port: 5671,
    username: process.env.AEM_USERNAME,
    password: process.env.AEM_PASSWORD,
    vhost: process.env.AEM_VPN,
    transport: "tls",
    reconnect: true,
    initial_reconnect_delay: 2000,
    max_reconnect_delay: 30000,
  });

  connection.on("disconnected", () => {
    console.warn("[AEM] Disconnected — reconnecting...");
  });

  connection.on("error", (err) => {
    console.error("[AEM] Connection error:", err.message);
  });

  await connection.open();
  console.log(`[AEM] Connected via AMQP to VPN: ${process.env.AEM_VPN}`);

  const receiver = await connection.createReceiver({
    source: {
      address: process.env.AEM_QUEUE,
      durable: 2,
      expiry_policy: "never",
    },
    credit_window: 1, // one message at a time
  });

  console.log(`[AEM] Subscribed to queue: ${process.env.AEM_QUEUE}`);

  receiver.on("message", async (context) => {
    const msg = context.message;

    console.log("[AEM] Message received");
    console.log("[AEM] Message body type:", typeof msg.body);
    console.log("[AEM] Message body:", JSON.stringify(msg.body));

    // Solace sends SF payload as binary attachment in msg.body
    // It may be a Buffer, a string, or nested in body.content
    let bodyStr = "";

    if (typeof msg.body === "string") {
      bodyStr = msg.body;
    } else if (Buffer.isBuffer(msg.body)) {
      bodyStr = msg.body.toString("utf8");
    } else if (msg.body?.content) {
      bodyStr = Buffer.isBuffer(msg.body.content)
        ? msg.body.content.toString("utf8")
        : String(msg.body.content);
    } else if (msg.body?.value) {
      bodyStr = String(msg.body.value);
    } else {
      bodyStr = JSON.stringify(msg.body);
    }

    console.log(`[AEM] Extracted body: ${bodyStr}`);

    // Acknowledge only after successful processing so message is not lost on error
    try {
      await onMessage(bodyStr);
      context.delivery.accept();
    } catch (err) {
      console.error("[AEM] Failed to process message — releasing back to queue:", err.message);
      context.delivery.release();
    }
  });

  process.on("SIGINT", async () => {
    console.log("\n[AEM] Shutting down...");
    await connection.close();
    process.exit(0);
  });
}
