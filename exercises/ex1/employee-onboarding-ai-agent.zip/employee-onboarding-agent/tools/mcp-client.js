// mcp-client.js
// Talks to the Integration Suite MCP Gateway.
// The participant's IAS access token is passed in — Integration Suite uses it
// to validate the caller's identity and propagate it to S/4HANA (Principal Propagation).

import fetch from "node-fetch";
import "dotenv/config";

const MCP_BASE = process.env.MCP_GATEWAY_URL;

// Build headers using the participant's own token (obtained after IAS login)
function makeHeaders(token) {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`,   // Integration Suite validates this against IAS
  };
}

// Fetch the list of available tools from the MCP Gateway
// These are passed to Claude so it knows what actions it can take
export async function listMCPTools(token) {
  const res = await fetch(`${MCP_BASE}/tools/list`, {
    method: "POST",
    headers: makeHeaders(token),
    body: "{}",
  });

  if (!res.ok) throw new Error(`MCP listTools failed: ${res.status} ${await res.text()}`);

  const data = await res.json();

  // Reshape MCP tool schema into the format Anthropic SDK expects
  return data.tools.map((tool) => ({
    name: tool.name,
    description: tool.description,
    input_schema: tool.inputSchema,
  }));
}

// Call a specific MCP tool (e.g. create_purchase_order, assign_training)
// Integration Suite receives the participant's token, extracts their identity,
// and propagates it to S/4HANA so the action is recorded under their name
export async function callMCPTool(toolName, toolInput, token) {
  const res = await fetch(`${MCP_BASE}/tools/call`, {
    method: "POST",
    headers: makeHeaders(token),
    body: JSON.stringify({ name: toolName, arguments: toolInput }),
  });

  if (!res.ok) throw new Error(`MCP callTool [${toolName}] failed: ${res.status} ${await res.text()}`);

  const data = await res.json();

  // MCP returns a content array — extract the text parts
  if (data.content) {
    return data.content
      .filter((c) => c.type === "text")
      .map((c) => c.text)
      .join("\n");
  }

  return data;
}
