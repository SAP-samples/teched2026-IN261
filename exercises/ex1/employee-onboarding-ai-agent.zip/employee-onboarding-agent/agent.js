import Anthropic from "@anthropic-ai/sdk";
import { connectAEM } from "./tools/aem-subscriber-amqp.js";
import { loginWithIAS } from "./tools/ias-login.js";
import { listMCPTools, callMCPTool } from "./tools/mcp-client.js";
import { readFileSync } from "fs";
import "dotenv/config";

// Usage: node agent.js

const anthropic = new Anthropic({
  apiKey: process.env.AICORE_API_KEY,
  baseURL: process.env.AICORE_BASE_URL,
  defaultHeaders: {
    "x-api-key": process.env.AICORE_API_KEY,
  },
});

// Load system prompt from file — edit prompts/employee-onboarding.md to change agent behaviour
const SYSTEM_PROMPT = readFileSync("./prompts/employee-onboarding.md", "utf8");

async function runEmployeeOnboardingAgent(newHirePayload, token) {
  console.log(`\n${"=".repeat(60)}`);
  console.log(`[Agent] New hire event received`);
  console.log(`${"=".repeat(60)}`);
  console.log(JSON.stringify(newHirePayload, null, 2));
  console.log(`${"=".repeat(60)}\n`);

  const userMessage = `A new employee has just joined the company. Here is the event data received from SAP SuccessFactors via Advanced Event Mesh:

${JSON.stringify(newHirePayload, null, 2)}

Please reason through the complete onboarding process for this employee, describing each step you would take, which SAP systems you would interact with via the MCP Gateway, and what the expected outcomes are.`;

  console.log("[Agent] Thinking...\n");

  // TODO: This single call will be replaced with a full agentic tool loop once the
  // Integration Suite MCP Gateway is hosted with the required onboarding tools.
  // The loop will keep calling Claude, executing tool_use responses via callMCPTool(),
  // and feeding results back until Claude returns a final text response.
  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 2048,
    system: SYSTEM_PROMPT,
    messages: [{ role: "user", content: userMessage }],
    tools: await listMCPTools(token),  // tools fetched from MCP Gateway using participant's token
  });

  const output = response.content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n");

  console.log("[Agent] Employee Onboarding Plan:\n");
  console.log(output);
  console.log(`\n${"=".repeat(60)}\n`);
}

async function main() {
  console.log("[Agent] SAP Employee Onboarding Agent starting...");

  // Step 1 — participant logs in via SAP IAS
  // Their identity will be propagated to S/4HANA for every action the agent takes
  const token = await loginWithIAS();

  // Decode JWT to show who is logged in (JWT middle segment is base64-encoded claims)
  const claims = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());
  console.log("[Agent] Logged in as:");
  console.log(`  Name:  ${claims.given_name} ${claims.family_name}`);
  console.log(`  Email: ${claims.email}`);
  console.log(`  User:  ${claims.sub}`);
  console.log();

  console.log(`[Agent] Queue: ${process.env.AEM_QUEUE}`);
  console.log("[Agent] Waiting for new hire events from SuccessFactors...\n");

  // Step 2 — connect to AEM and process events as they arrive
  await connectAEM(async (message) => {
    let payload = {};
    try {
      if (message && message.trim().length > 0) {
        payload = JSON.parse(message);
      } else {
        console.log("[Agent] Empty event body received — skipping");
        return;
      }
    } catch {
      payload = { raw: message };
    }
    try {
      await runEmployeeOnboardingAgent(payload, token);
    } catch (err) {
      console.error("[Agent] Error processing event:", err.message);
    }
  });
}

main().catch((err) => {
  console.error("[Agent] Fatal error:", err);
  process.exit(1);
});
