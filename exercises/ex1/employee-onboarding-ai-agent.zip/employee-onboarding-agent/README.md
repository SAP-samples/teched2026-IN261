# Employee Onboarding AI Agent

Claude-powered agent that listens for new hire events from SAP SuccessFactors via Advanced Event Mesh and orchestrates the full onboarding process through SAP Integration Suite.

## Architecture

```
SuccessFactors (HiringComplete notification event — no payload details)
        │
        ▼
SAP Advanced Event Mesh
        │
        ▼  (your assigned queue)
Employee Onboarding AI Agent  ←── you run this on your laptop
        │
        ├── Tool 1: get_new_hire_details
        │     API composition via Integration Suite
        │     combines SuccessFactors Employee, Job, and Manager APIs
        │     returns full new hire profile in one call
        │
        ├── Tool 2: get_company_policy
        │     reads onboarding policy grounded via RAG
        │     backed by SAP AI Launchpad Orchestration flow
        │     returns role/location-specific equipment and access policies
        │
        │   ── Human-in-the-Loop ──────────────────────────────────────
        │     Agent presents onboarding plan to manager for approval
        │     workflow pauses until manager approves
        │   ─────────────────────────────────────────────────────────────
        │
        ├── Tool 3: create_purchase_requisition  (after manager approval)
        │     creates PR in SAP S/4HANA On-Premise
        │     your IAS identity propagated via Principal Propagation
        │     PR recorded under your name in S/4 audit log
        │
        └── Tool 4: create_service_cloud_ticket  (after manager approval)
              creates ticket in SAP Service Cloud
              covers both IT system access and training enrollment requests

        All tools exposed via SAP Integration Suite MCP Gateway
        which enforces authentication, audit logging, and PP
```

## What happens when you run it

1. Your browser opens → log in with your SAP IAS credentials
2. Agent confirms your identity in the terminal
3. Agent connects to your AEM queue and waits for a new hire event
4. New hire notification arrives → agent fetches full employee, job and manager details via API composition
5. Agent reads company policy via RAG-grounded AI Launchpad Orchestration flow
6. Agent presents onboarding plan → **manager approves** (human-in-the-loop)
7. After approval → Purchase Requisition created in S/4HANA On-Premise under your identity via PP
8. After approval → Service Cloud ticket created for IT access and training enrollment

## Setup

### 1. Prerequisites

- [Node.js](https://nodejs.org) v18 or higher
- A SAP IAS account (provided by the workshop instructor)

### 2. Clone and install

```bash
git clone <repo-url>
cd employee-onboarding-agent
npm install
```

### 3. Configure

```bash
cp .env.example .env
```

Open `.env` and fill in the values provided by your instructor:

| Variable | Description |
|---|---|
| `AICORE_API_KEY` | Provided separately by instructor |
| `AEM_USERNAME` | Provided separately by instructor |
| `AEM_PASSWORD` | Provided separately by instructor |
| `AEM_QUEUE` | Your assigned queue e.g. `onboarding/participant-01` |

**Pre-configured for this workshop — do not change:**

| Variable | Value |
|---|---|
| `AICORE_BASE_URL` | Shared AI Core proxy |
| `AEM_VPN` | Shared AEM Message VPN |
| `AEM_REST_URL` | Shared AEM REST URL |
| `MCP_GATEWAY_URL` | Shared Integration Suite MCP Gateway |
| `IAS_TENANT` | Shared IAS tenant |
| `OIDC_CLIENT_ID` | Shared OIDC client |
| `OIDC_REDIRECT_URI` | `http://localhost:3000/callback` |

### 4. Test your login

```bash
node test-login.js
```

Your browser will open the SAP IAS login page. After logging in you should see your name and email printed in the terminal.

### 5. Run the agent

```bash
node agent.js
```

Log in when the browser opens, then wait for your instructor to trigger a new hire event.

## Troubleshooting

**Port 3000 already in use**
```bash
# Find the process
netstat -ano | findstr :3000

# Stop it
taskkill /PID <pid> /F
```

**Browser does not open automatically**
Copy the URL printed in the terminal and open it manually.

**Token exchange fails**
Make sure `http://localhost:3000/callback` is added as a redirect URI in the IAS app settings.

## Project Structure

| File | Purpose |
|---|---|
| `agent.js` | The agent itself — Claude agentic loop, entry point |
| `test-login.js` | Verify your IAS login works before running the full agent |
| `tools/ias-login.js` | IAS login flow — OIDC + PKCE, opens browser, returns token |
| `tools/aem-subscriber-amqp.js` | Connects to AEM queue via AMQP, receives new hire events |
| `tools/mcp-client.js` | Calls Integration Suite MCP Gateway with your identity token |
| `prompts/employee-onboarding.md` | Claude system prompt — defines what the agent does |
| `package.json` | Defines dependencies — needed for `npm install` |
| `package-lock.json` | Locks exact dependency versions for consistent installs |
| `.env.example` | Template — copy to `.env` and fill in your values |
| `.gitignore` | Prevents credentials being accidentally committed |
| `README.md` | This file |
